module.exports = {
  globals: {
    'beforeAll': false,
    'describe': false,
    'it': false,
    'QUnit': false
  },
  rules: {
    'no-unsanitized/property': 0,
  }
}
